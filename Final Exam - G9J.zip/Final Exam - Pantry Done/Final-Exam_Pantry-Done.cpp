#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CLEAR system("cls || clear")
const int max_hash_row = 26;

struct OnlineIngredients{
    char name[30+1], unit_type[10+1], save_flag;
    struct OnlineIngredients *next;
};

struct Ingredients{
    char name[30+1], unit_type[10+1];
    float amount;
    struct Ingredients *next;
};

struct Instructions{
    char step[100+1];
    struct Instructions *next;
};

struct Recipe{ //Single linked List
    //save_flag hanya sebagai flag untuk membedakan antara yang sudah di-save dengan yang belum
    //dan yang sudah di show di homepage dengan yang belum.
    char name[50+1], description[250+1], save_flag, home_show_flag;
    struct Instructions *first_instruction, *last_instruction; //single linked list
    struct Ingredients *first_ingredients, *last_ingredients; //single linked list
    struct Recipe *next_recipe, *next_saved;
};

//saved untuk hash table yang udah disave
//online untuk hash table dari file
//tail untuk tail dari suatu hash table
struct Recipe *saved_recipe[max_hash_row], *saved_recipe_tail[max_hash_row], *online_recipe[max_hash_row], *online_recipe_tail[max_hash_row];
struct Ingredients *saved_ingredient[max_hash_row], *saved_ingredient_tail[max_hash_row];
struct OnlineIngredients *online_ingredient[max_hash_row], *online_ingredient_tail[max_hash_row];

void fill_recipe_hash_table(struct Recipe **newNode, int hash_index, struct Recipe *global_head[], struct Recipe *global_tail[]){ //Use PushMid
    if((global_tail[hash_index]) == NULL){
        (global_head[hash_index]) = (global_tail[hash_index]) = *newNode;
    }
    else if(strcmp((*global_head[hash_index]).name, (*newNode)->name) > 0){
        (*newNode)->next_recipe = (global_head[hash_index]);
        (global_head[hash_index]) = *newNode;
    }
    else if(strcmp((global_tail[hash_index])->name, (*newNode)->name) < 0){
        (global_tail[hash_index])->next_recipe = *newNode;
        (global_tail[hash_index]) = *newNode;
    }
    else{
        struct Recipe *current = (Recipe *) malloc(sizeof(Recipe));
        struct Recipe *temp_current = (Recipe *) malloc(sizeof(Recipe));
        temp_current = (global_head[hash_index]);
        current = (global_head[hash_index])->next_recipe;
        while(current != NULL){
            if(strcmp(current->name, (*newNode)->name) > 0){
                break;
            }
            temp_current = current;
            current = current->next_recipe;
        }
        temp_current->next_recipe = *newNode;
        (**newNode).next_recipe = current;
    }
}

void fill_online_recipe(FILE *recipe_source){
    char temp[251+1], type_temp[11+1]; //extra 1 index for length validation
    float amount_temp = 0.0; //for ingredients in recipe
    int hash_index; //for ingredients in recipe
    for(; !feof(recipe_source); ){
        struct Recipe *newNode = (Recipe *) malloc(sizeof(Recipe));

        for(int i=1; i<=4; i++){
            if(i != 4){
                fscanf(recipe_source, "%[^\n]\n", temp);
            }
            if(i == 1){ //Inisialisasi awal untuk newNode
                if(temp[0] >= 'a' && temp[0] <= 'z'){
                    temp[0] -= 'a' - 'A';
                }
                hash_index = temp[0]-'A';
                
                strcpy(newNode->name, temp);
                newNode->next_recipe = newNode->next_saved = NULL;
                newNode->first_instruction = newNode->last_instruction = NULL;
                newNode->first_ingredients = newNode->last_ingredients = NULL;
                newNode->save_flag = newNode->home_show_flag = '0';
            }
            else if(i == 2){ //fill the description
                strcpy(newNode->description, temp);
            }
            else if(i == 3){ //fill the instruction
                for(;;){
                    if(temp[0] == '-'){
                        break;
                    }
                    struct Instructions *newInstruction = (Instructions *) malloc(sizeof(Instructions));
                    strcpy(newInstruction->step, temp);
                    newInstruction->next = NULL;
                    if(newNode->last_instruction == NULL){
                        newNode->first_instruction = newNode->last_instruction = newInstruction;
                    }
                    else{
                        newNode->last_instruction->next = newInstruction;
                        newNode->last_instruction = newInstruction;
                    }
                    fscanf(recipe_source, "%[^\n]\n", temp);
                }
            }
            else if(i == 4){ //fill the ingredients
                for(;;){
                    fscanf(recipe_source, "%[^|]|", temp);
                    if(temp[0] == '-'){
                        fscanf(recipe_source, "\n");
                        break;
                    }
                    else{
                        fscanf(recipe_source, "%f|%[^\n]\n", &amount_temp, type_temp);
                    }
                    struct Ingredients *newIngredients = (Ingredients *) malloc(sizeof(Ingredients));
                    strcpy(newIngredients->name, temp);
                    newIngredients->amount = amount_temp;
                    strcpy(newIngredients->unit_type, type_temp);
                    newIngredients->next = NULL;
                    
                    if(newNode->last_ingredients == NULL){
                        newNode->first_ingredients = newNode->last_ingredients = newIngredients;
                    }
                    else{
                        newNode->last_ingredients->next = newIngredients;
                        newNode->last_ingredients = newIngredients;
                    }
                }
            }
        }
        //newNode DONE

        fill_recipe_hash_table(&newNode, hash_index, online_recipe, online_recipe_tail); //insert newNode to hash table
    }
}

void fill_ingredient_hash_table(struct OnlineIngredients **newNode, int hash_index){ //Use PushMid
    if(online_ingredient_tail[hash_index] == NULL){
        online_ingredient[hash_index] = online_ingredient_tail[hash_index] = *newNode;
    }
    else if(strcmp(online_ingredient[hash_index]->name, (*newNode)->name) > 0){
        (*newNode)->next = online_ingredient[hash_index];
        online_ingredient[hash_index] = *newNode;
    }
    else if(strcmp(online_ingredient_tail[hash_index]->name, (*newNode)->name) < 0){
        online_ingredient_tail[hash_index]->next = *newNode;
        online_ingredient_tail[hash_index] = *newNode;
    }
    else{
        struct OnlineIngredients *current = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
        struct OnlineIngredients *temp_current = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
        temp_current = online_ingredient[hash_index];
        current = online_ingredient[hash_index]->next;
        while(current != NULL){
            if(strcmp(current->name, (*newNode)->name) > 0){
                break;
            }
            temp_current = current;
            current = current->next;
        }
        temp_current->next = *newNode;
        (**newNode).next = current;
    }
}

void fill_online_ingredient(FILE *ingredient_source){
    char temp[31+1], type_temp[11+1]; //extra 1 index for length validation
    int hash_index; //for ingredients in recipe
    for(; !feof(ingredient_source); ){
        struct OnlineIngredients *newNode = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
        fscanf(ingredient_source, "%[^|]|%[^\n]\n\n", temp, type_temp);
        if(temp[0] >= 'a' && temp[0] <= 'z'){
            temp[0] -= 'a' - 'A';
        }
        hash_index = temp[0]-'A';
        strcpy(newNode->name, temp);
        strcpy(newNode->unit_type, type_temp);
        newNode->save_flag = '0';
        newNode->next = NULL;
        //newNode DONE

        fill_ingredient_hash_table(&newNode, hash_index); //insert newNode to hash table
    }
}

void printAllRecipe(struct Recipe *global_variable[]){
    int number=1;
    for(int i=0; i<max_hash_row; i++){
        struct Recipe *current_recipe = (Recipe *) malloc(sizeof(Recipe));
        current_recipe = global_variable[i];
        while(current_recipe != NULL){
            printf("%-2d Name: %s\n", number++, current_recipe->name);
            printf("Description: %s\n\n", current_recipe->description);
            current_recipe = current_recipe->next_recipe;
        }
    }
}

void printSavedRecipe(struct Recipe *global_variable[]){
    int number=1;
    char flag = '0';
    for(int i=0; i<max_hash_row; i++){
        struct Recipe *current_recipe = (Recipe *) malloc(sizeof(Recipe));
        current_recipe = global_variable[i];
        while(current_recipe != NULL){
            if(flag == '0'){
                flag = '1';
            }
            printf("%-2d Name: %s\n", number++, current_recipe->name);
            printf("Description: %s\n\n", current_recipe->description);
            current_recipe = current_recipe->next_saved;
        }
    }
    if(flag == '0'){
        printf("There's no recipe has been saved!");
    }
}

void add_saved_recipe(struct Recipe **current_recipe, int hash_index){
    if(saved_recipe_tail[hash_index] == NULL){
        saved_recipe[hash_index] = saved_recipe_tail[hash_index] = (*current_recipe);
    }
    else if(strcmp(saved_recipe[hash_index]->name, (*current_recipe)->name) > 0){
        (*current_recipe)->next_saved = saved_recipe[hash_index];
        saved_recipe[hash_index] = (*current_recipe);
    }
    else if(strcmp(saved_recipe_tail[hash_index]->name, (*current_recipe)->name) < 0){
        saved_recipe_tail[hash_index]->next_saved = (*current_recipe);
        saved_recipe_tail[hash_index] = (*current_recipe);
    }
    else{
        struct Recipe *current = (Recipe *) malloc(sizeof(Recipe));
        current = saved_recipe[hash_index]->next_saved;
        struct Recipe *temp_current = (Recipe *) malloc(sizeof(Recipe));
        temp_current = saved_recipe[hash_index];
        while(current != NULL){
            if(strcmp(current->name, (*current_recipe)->name) > 0){
                break;
            }
            temp_current = current;
            current = current->next_saved;
        }
        temp_current->next_saved = (*current_recipe);
        (*current_recipe)->next_saved = current;
    }
}

void search_recipe(char recipe_name[]){
    if(recipe_name[0] >= 'a' && recipe_name[0] <= 'z'){
        recipe_name[0] -= 'a' - 'A';
    }
    int hash_index = recipe_name[0]-'A';

    char temp1[50+1], temp2[50+1];
    struct Recipe *current_recipe = (Recipe *) malloc(sizeof(Recipe));
    current_recipe = online_recipe[hash_index];
    strcpy(temp2, recipe_name);
    strlwr(temp2);

    if(current_recipe == NULL){
        printf("Recipe didn't found!");
        getchar();
        return;
    }
    while(current_recipe != NULL){
        strcpy(temp1, current_recipe->name);
        strlwr(temp1);
        if(strcmp(temp1, temp2) == 0){
            if(current_recipe->save_flag == '1'){
                printf("Choosen recipe already saved!");
                getchar();
                return;
            }

            struct Instructions *current_instruction = (Instructions *) malloc(sizeof(Instructions));
            struct Ingredients *current_ingredients = (Ingredients *) malloc(sizeof(Ingredients));
            printf("Name: %s\n", current_recipe->name);
            printf("Description: %s\n", current_recipe->description);
            puts("\nInstruction:");
            current_instruction = current_recipe->first_instruction;
            for(int j=1; current_instruction != NULL; j++){
                printf("%-3d %s\n", j, current_instruction->step);
                current_instruction = current_instruction->next;
            }
            puts("\nIngredients:");
            current_ingredients = current_recipe->first_ingredients;
            for(; current_ingredients != NULL;){
                printf("# %s - %.2f %s\n", current_ingredients->name, current_ingredients->amount, current_ingredients->unit_type);
                current_ingredients = current_ingredients->next;
            }

            puts("\nAdd to Saved Recipe? (Yes/No)");
            char temp;
            printf(">> "); scanf("%c%*s", &temp); getchar();
            if(temp == 'n' || temp == 'N'){
                return;
            }
            else if(temp == 'y' || temp == 'Y'){
                current_recipe->save_flag = '1';
                add_saved_recipe(&current_recipe, hash_index);
                return;
            }
        }
        else if(strcmp(temp1, temp2) > 0 || current_recipe->next_recipe == NULL){
            printf("Recipe didn't found!");
            getchar();
            return;
        }
        else{
            current_recipe = current_recipe->next_recipe;
        }
    }
}

char search_recipe_keyword(char recipe_keyword[]){
    if(recipe_keyword[0] >= 'a' && recipe_keyword[0] <= 'z'){
        recipe_keyword[0] -= 'a' - 'A';
    }
    int hash_index = recipe_keyword[0] - 'A';
    int len;
    struct Recipe *current = (Recipe *) malloc(sizeof(Recipe));
    current = online_recipe[hash_index];
    if(current == NULL){
        printf("Recipe didn't found, please use another keyword!");
        getchar();
        return '0';
    }
    for(;;){
        char *test = strstr(current->name, recipe_keyword);
        
        if(test != NULL){
            int number = 1;
            struct Recipe *current_recipe = (Recipe *) malloc(sizeof(Recipe));
            current_recipe = current;
            while(strstr(current_recipe->name, recipe_keyword) != NULL){
                printf("%-2d Name: %s\n", number++, current_recipe->name);
                printf("Description: %s\n\n", current_recipe->description);
                current_recipe = current_recipe->next_recipe;
                if(current_recipe == NULL){
                    break;
                }
            }
            return '1';
        }
        if(current->next_recipe == NULL){
            current = online_recipe[hash_index];
            len = strlen(recipe_keyword);
            recipe_keyword[len-1] = '\0';
            if(len == 1){
                printf("Recipe didn't found, please use another keyword!");
                getchar();
                return '0';
            }
        }
        else{
            current = current->next_recipe;
        }
    }
}

void printCookBook() {
    bool inMenu = true;
    while(inMenu) {
        int menu = 0;
        CLEAR;
        Recipe *addedRecipe = NULL;
        Recipe *deletedRecipe = NULL;
        puts(" === CookPedia ===");
        puts("1. Show Saved recipes");
        puts("2. Add recipes from online recipes");
        puts("3. Manually add recipes");
        puts("4. Delete saved recipes");
        puts("5. Back to main screen");
        printf(">> "); scanf("%d", &menu); getchar();
        if(menu == 1) {
            printSavedRecipe(saved_recipe);
            getchar();
        }
        else if(menu == 2){
            char select, flag = '1';
            puts("1. Show All Online Recipes");
            puts("2. Search Recipe by Keyword");
            printf(">> "); scanf("%c", &select); getchar();
            switch(select){
                case '1':
                    printAllRecipe(online_recipe);
                    break;
                case '2':
                    printf("Recipe Keyword: ");
                    char recipe_keyword[50+1];
                    scanf("%[^\n]", recipe_keyword);
                    getchar();
                    flag = search_recipe_keyword(recipe_keyword);
                    break;
            }
            if(flag == '1'){
                char recipe_name[50+1];
                printf("The name of the recipe would you like to look (type 0 to cancel): ");
                scanf("%[^\n]", recipe_name); getchar();
                if(recipe_name[0] != '0'){
                    search_recipe(recipe_name);
                }
            }
        }
        else if(menu == 3){
            puts("NOT DONE");
        }
        else if(menu == 4){
            puts("NOT DONE");
        }
        else if(menu == 5){
            inMenu = false;
            break;
        }
    }
    fflush(stdin);
}

//Pantry Coding Part -----------------------------------------------------------------------------------------------------

void printSavedIngredients(){
    int number=1;
    char flag = '0';
    for(int i=0; i<max_hash_row; i++){
        struct Ingredients *current_ingredients = (Ingredients *) malloc(sizeof(Ingredients));
        current_ingredients = saved_ingredient[i];
        while(current_ingredients != NULL){
            if(flag == '0'){
                flag = '1';
            }
            printf("%-2d %-30s - %.2f %s\n", number++, current_ingredients->name, current_ingredients->amount, current_ingredients->unit_type);
            current_ingredients = current_ingredients->next;
        }
    }
    if(flag == '0'){
        printf("There's no ingredient in Pantry!");
    }
}

void printAllOnlineIngredients(){
    int number=1;
    for(int i=0; i<max_hash_row; i++){
        struct OnlineIngredients *current_ingredients = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
        current_ingredients = online_ingredient[i];
        while(current_ingredients != NULL){
            printf("%-2d %-30s - %s\n", number++, current_ingredients->name, current_ingredients->unit_type);
            current_ingredients = current_ingredients->next;
        }
    }
}

void add_ingredient(struct Ingredients **current_ingredient, int hash_index){
    if(saved_ingredient_tail[hash_index] == NULL){
        saved_ingredient[hash_index] = saved_ingredient_tail[hash_index] = (*current_ingredient);
    }
    else if(strcmp(saved_ingredient[hash_index]->name, (*current_ingredient)->name) > 0){
        (*current_ingredient)->next = saved_ingredient[hash_index];
        saved_ingredient[hash_index] = (*current_ingredient);
    }
    else if(strcmp(saved_ingredient_tail[hash_index]->name, (*current_ingredient)->name) < 0){
        saved_ingredient_tail[hash_index]->next = (*current_ingredient);
        saved_ingredient_tail[hash_index] = (*current_ingredient);
    }
    else{
        struct Ingredients *current = (Ingredients *) malloc(sizeof(Ingredients));
        current = saved_ingredient[hash_index]->next;
        struct Ingredients *temp_current = (Ingredients *) malloc(sizeof(Ingredients));
        temp_current = saved_ingredient[hash_index];
        while(current != NULL){
            if(strcmp(current->name, (*current_ingredient)->name) > 0){
                break;
            }
            temp_current = current;
            current = current->next;
        }
        temp_current->next = (*current_ingredient);
        (*current_ingredient)->next = current;
    }
}

void plus_ingredient(float temp_amount, char ingredient_name[], char ingredient_type[], int hash_index){
    struct Ingredients *current_ingredients = (Ingredients *) malloc(sizeof(Ingredients));
    current_ingredients = saved_ingredient[hash_index];
    while(current_ingredients != NULL){
        if(strcmpi(current_ingredients->name, ingredient_name) == 0 && strcmpi(current_ingredients->unit_type, ingredient_type) == 0){
            current_ingredients->amount += temp_amount;
            break;
        }
        current_ingredients = current_ingredients->next;
    }
    printf("\n%.2f %s of %s successful added to the Pantry!\n", temp_amount, ingredient_type, ingredient_name);
    printf("Now you have %.2f %s of %s in the Pantry.", current_ingredients->amount, ingredient_type, ingredient_name);
}

void search_ingredient(char ingredient_name[], char ingredient_type[]){

    if(ingredient_name[0] >= 'a' && ingredient_name[0] <= 'z'){
        ingredient_name[0] -= 'a' - 'A';
    }
    int hash_index = ingredient_name[0]-'A';

    char temp1[30+1], temp2[10+1];
    struct OnlineIngredients *current_ingredients = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
    current_ingredients = online_ingredient[hash_index];

    if(current_ingredients == NULL){
        printf("Ingredient didn't found!");
        getchar();
        return;
    }

    strlwr(ingredient_name);
    strlwr(ingredient_type);
    while(current_ingredients != NULL){
        strcpy(temp1, current_ingredients->name);
        strlwr(temp1);
        strcpy(temp2, current_ingredients->unit_type);
        strlwr(temp2);
        if(strcmp(temp1, ingredient_name) == 0 && strcmp(temp2, ingredient_type) == 0){
            if(current_ingredients->save_flag == '1'){
                float temp_amount;
                for(;;){
                    printf("Amount to add to the Pantry (type 0 to cancel): ");
                    scanf("%f", &temp_amount); getchar();
                    if(temp_amount >= 0){
                        break;
                    }
                    else{
                        puts("Invalid amount!\n");
                    }
                }
                plus_ingredient(temp_amount, ingredient_name, ingredient_type, hash_index);
                getchar();
                return;
            }

            Ingredients *new_ingredient = (Ingredients *) malloc(sizeof(Ingredients));
            strcpy(new_ingredient->name, current_ingredients->name);
            new_ingredient->amount = 0;
            strcpy(new_ingredient->unit_type, current_ingredients->unit_type);
            new_ingredient->next = NULL;

            current_ingredients->save_flag = '1';
            add_ingredient(&new_ingredient, hash_index);
            printf("\"%s - %s\" success added to the Pantry!", new_ingredient->name, new_ingredient->unit_type);
            getchar();
            return;
        }
        else if(strcmp(temp1, ingredient_name) > 0 || current_ingredients->next == NULL){
            printf("Ingredient didn't found!");
            getchar();
            return;
        }
        else{
            current_ingredients = current_ingredients->next;
        }
    }
}

char search_ingredient_keyword(char ingredient_keyword[]){
    if(ingredient_keyword[0] >= 'a' && ingredient_keyword[0] <= 'z'){
        ingredient_keyword[0] -= 'a' - 'A';
    }
    int hash_index = ingredient_keyword[0] - 'A';
    int len;
    struct OnlineIngredients *current = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
    current = online_ingredient[hash_index];
    if(current == NULL){
        printf("Ingredient didn't found, please use another keyword!");
        getchar();
        return '0';
    }
    for(;;){
        char *test = strstr(current->name, ingredient_keyword);
        
        if(test != NULL){
            int number = 1;
            struct OnlineIngredients *current_ingredient = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
            current_ingredient = current;
            while(strstr(current_ingredient->name, ingredient_keyword) != NULL){
                printf("%-2d %-30s - %s\n", number++, current_ingredient->name, current_ingredient->unit_type);
                current_ingredient = current_ingredient->next;
                if(current_ingredient == NULL){
                    break;
                }
            }
            return '1';
        }
        if(current->next == NULL){
            current = online_ingredient[hash_index];
            len = strlen(ingredient_keyword);
            ingredient_keyword[len-1] = '\0';
            if(len == 1){
                printf("Ingredient didn't found, please use another keyword!");
                getchar();
                return '0';
            }
        }
        else{
            current = current->next;
        }
    }
}

void create_new_ingredient(char temp_name[], char temp_type[]){
    if(temp_name[0] >= 'a' && temp_name[0] <= 'z'){
        temp_name[0] -= 'a' - 'A';
    }
    int hash_index = temp_name[0]-'A';

    OnlineIngredients *new_online_ingredient = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
    strcpy(new_online_ingredient->name, temp_name);
    strcpy(new_online_ingredient->unit_type, temp_type);
    new_online_ingredient->save_flag = '1';
    new_online_ingredient->next = NULL;
    fill_ingredient_hash_table(&new_online_ingredient, hash_index);

    Ingredients *new_ingredient = (Ingredients *) malloc(sizeof(Ingredients));
    strcpy(new_ingredient->name, temp_name);
    strcpy(new_ingredient->unit_type, temp_type);
    new_ingredient->amount = 0;
    new_ingredient->next = NULL;
    add_ingredient(&new_ingredient, hash_index);

    printf("\"%s - %s\" success added to the Pantry!", new_ingredient->name, new_ingredient->unit_type);
    getchar();
}

char check_ingredient(char ingredient_name[], char ingredient_type[]){
    if(ingredient_name[0] >= 'a' && ingredient_name[0] <= 'z'){
        ingredient_name[0] -= 'a' - 'A';
    }
    int hash_index = ingredient_name[0]-'A';

    char temp1[30+1], temp2[10+1];
    struct OnlineIngredients *current_ingredients = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
    current_ingredients = online_ingredient[hash_index];

    if(current_ingredients == NULL){
        return '0';
    }

    strlwr(ingredient_name);
    strlwr(ingredient_type);
    while(current_ingredients != NULL){
        strcpy(temp1, current_ingredients->name);
        strlwr(temp1);
        strcpy(temp2, current_ingredients->unit_type);
        strlwr(temp2);
        if(strcmp(temp1, ingredient_name) == 0 && strcmp(temp2, ingredient_type) == 0){
            return '1';
        }
        else if(strcmp(temp1, ingredient_name) > 0 || current_ingredients->next == NULL){
            return '0';
        }
        else{
            current_ingredients = current_ingredients->next;
        }
    }
}

void change_online_flag(char temp_name[], char temp_type[], int hash_index){
    OnlineIngredients *current = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
    current = online_ingredient[hash_index];

    for(;current != NULL;){
        if(strcmpi(current->name, temp_name) == 0 && strcmpi(current->unit_type, temp_type) == 0){
            printf("Name: %s\n", current->name);
            printf("Unit Type: %s\n", current->unit_type);
            printf("Save Flag: %c\n", current->save_flag);
            current->save_flag = '0';
            return;
        }
        current = current->next;
    }
    printf("Error (Bug)\n");
    getchar();
}

void remove(struct Ingredients **current, struct Ingredients **temp_current, int hash_index){
    if((*current) == saved_ingredient[hash_index] && (*current) == saved_ingredient_tail[hash_index]){
        saved_ingredient[hash_index] = saved_ingredient_tail[hash_index] = NULL;
    }
    else if((*current) == saved_ingredient[hash_index]){
        saved_ingredient[hash_index] = (**current).next;
    }
    else if((*current) == saved_ingredient_tail[hash_index]){
        saved_ingredient_tail[hash_index] = (*temp_current);
        (*temp_current)->next = NULL;
    }
    else{
        (**temp_current).next = (*current)->next;
    }
    (**current).next = NULL;
    free(*current);
}

void remove_ingredient(char temp_name[], char temp_type[]){
    if(temp_name[0] >= 'a' && temp_name[0] <= 'z'){
        temp_name[0] -= 'a' - 'A';
    }
    int hash_index = temp_name[0]-'A';
    Ingredients *current = (Ingredients *) malloc(sizeof(Ingredients));
    current = saved_ingredient[hash_index];
    Ingredients *temp_current = (Ingredients *) malloc(sizeof(Ingredients));

    for(;current != NULL;){
        if(strcmpi(current->name, temp_name) == 0 && strcmpi(current->unit_type, temp_type) == 0){
            char answer;
            puts("\n[CONFIRMATION]");
            puts("Ingredient Information:");
            printf("Name: %s\n", current->name);
            printf("Unit Type: %s\n", current->unit_type);
            printf("Amount in Pantry: %.2f\n", current->amount);

            puts("\nAre you sure want to remove it from Pantry? (Yes/No)");
            printf(">> "); scanf("%c%*s", &answer); getchar(); 
            if(answer == 'n' || answer == 'N'){
                return;
            }
            else if(answer == 'y' || answer == 'Y'){
                change_online_flag(temp_name, temp_type, hash_index);
                remove(&current, &temp_current, hash_index);
                return;
            }
        }
        temp_current = current;
        current = current->next;
    }
    if(current == NULL){
        printf("The ingredient didn't found in Pantry!");
        getchar();
        return;
    }
}

void pantry_menu(){
    for(char choice;;){
        CLEAR;
        puts(" ===== Pantry =====");
        puts("1. Show Ingredients");
        puts("2. Add Ingredient");
        puts("3. Remove an Ingredient");
        puts("4. Back to main screen");
        printf(">> "); scanf("%c", &choice); getchar();

        if(choice == '1'){
            printSavedIngredients();
            getchar();
        }
        else if(choice == '2'){
            puts("1. Show all ingredients in online source");
            puts("2. Search ingredient by name");
            puts("3. Create new/custom ingredient");
            printf(">> "); scanf("%c", &choice); getchar();

            char flag = '1';
            if(choice == '1'){
                printAllOnlineIngredients();
            }
            else if(choice == '2'){
                printf("Ingredient Keyword: ");
                char ingredient_keyword[30+1];
                scanf("%[^\n]", ingredient_keyword);
                getchar();
                flag = search_ingredient_keyword(ingredient_keyword);
            }
            else if(choice == '3'){
                flag = '0';
                char temp_name[30+1], temp_type[10+1];
                printf("The name of the ingredient (type 0 to cancel): ");
                scanf("%[^\n]", temp_name); getchar();
                printf("Unit type of the ingredient (type 0 to cancel): ");
                scanf("%[^\n]", temp_type); getchar();
                if(temp_name[0] != '0' && temp_type[0] != '0'){
                    flag = check_ingredient(temp_name, temp_type);
                    if(flag == '0'){
                        create_new_ingredient(temp_name, temp_type);
                    }
                    else if(flag == '1'){
                        printf("\"%s - %s\" already exist!", temp_name, temp_type);
                        getchar();
                    }
                }
            }

            if(flag == '1'){ //Untuk memilih ingredient yang mau di-add ke Pantry
                char temp_name[30+1], temp_type[10+1];
                printf("The name of ingredient would you like to add to Pantry (type 0 to cancel): ");
                scanf("%[^\n]", temp_name); getchar();
                printf("Unit type of the ingredient (type 0 to cancel): ");
                scanf("%[^\n]", temp_type); getchar();
                if(temp_name[0] != '0' && temp_type[0] != '0'){
                    search_ingredient(temp_name, temp_type);
                }
            }
        }
        else if(choice == '3'){
            printSavedIngredients();
            char temp_name[30+1], temp_type[10+1];
            printf("\nThe name of ingredient would you like to remove from Pantry (type 0 to cancel): ");
            scanf("%[^\n]", temp_name); getchar();
            printf("Unit type of the ingredient (type 0 to cancel): ");
            scanf("%[^\n]", temp_type); getchar();
            if(temp_name[0] != '0' && temp_type[0] != '0'){
                remove_ingredient(temp_name, temp_type);
            }
        }
        else if(choice == '4'){
            break;
        }
    }
}


//Exit coding part ---------------------------------------------------------------------------------------
void rewrite_ingredient_file(){
    FILE *ingredient = fopen("Ingredients.txt", "w");
    OnlineIngredients *current = (OnlineIngredients *) malloc(sizeof(OnlineIngredients));
    for(int i=0; i<max_hash_row; i++){
        current = online_ingredient[i];
        for(;current != NULL;){
            fprintf(ingredient, "%s|%s\n", current->name, current->unit_type);
            current = current->next;
        }
    }
    fclose(ingredient);
}

int main(){
    FILE *recipe_source = fopen("Recipes.txt", "r");
    fill_online_recipe(recipe_source); //transfer recipe from file into hash table
    fclose(recipe_source);

    FILE *ingredient_source = fopen("Ingredients.txt", "r");
    fill_online_ingredient(ingredient_source);
    fclose(ingredient_source);
    // debug_print();
    
    bool inMenu = true;
    while(inMenu) {
        int menu = 0;
        CLEAR;
        printf("WELCOME TO WHISK\n");
        puts("Your Number One Cooking Partner!\n");
        puts("1. Your Profile");
        puts("2. Home Page");
        puts("3. CookPedia");
        puts("4. Pantry");
        puts("5. Kitchen");
        puts("6. Exit");
        printf("Please insert your choice: "); scanf("%d", &menu); getchar();
        switch(menu) {
            case 1:
                puts("This menu is not yet available");
                getchar();
                break;
            case 2:
                // printHomePage(recipes);
                puts("NOT DONE");
                getchar();
                break;
            case 3:
                printCookBook();
                break;
            case 4:
                pantry_menu();
                break;
            case 5:
                // kitchenMenu(users, recipes);
                puts("NOT DONE");
                getchar();
                break;
            case 6:
                // inMenu = false; //Buka lagi ketika program sudah selesai
                // rewrite_ingredient_file();
                break;
        }
        fflush(stdin);
    }
    printf("Thankyou for using our program! ^_^\n\n");
    return 0;
}

/* Reminder Note:
- Database ingredient diurutkan berdasarkan abjad, tpi klo misal ada yg sama nama ingredientnya, maka urutkan dari satuannya.
*/